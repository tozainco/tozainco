const V='quatre-livres-v27';
const SHELL=['./','./index.html','./manifest.webmanifest','./coran.js','./torah.js','./zabour.js','./injil.js','./icons/icon-192.png','./icons/icon-512.png'];
const OPT=['./mot-a-mot.js','./mot-a-mot-torah.js','./mot-a-mot-zabour.js','./mot-a-mot-injil.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>Promise.all(SHELL.concat(OPT).map(u=>c.add(u).catch(()=>{})))).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  if(e.request.destination==='audio'||e.request.headers.has('range'))return;
  const nav=e.request.mode==='navigate';
  e.respondWith(nav?fetch(e.request).then(r=>{const c=r.clone();caches.open(V).then(x=>x.put('./index.html',c));return r}).catch(()=>caches.match('./index.html'))
  :caches.match(e.request).then(h=>h||fetch(e.request).then(r=>{if(r&&(r.ok||r.type==='opaque')){const c=r.clone();caches.open(V).then(x=>x.put(e.request,c))}return r})));
});
