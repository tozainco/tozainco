#!/usr/bin/env python3
"""Vérifie les fichiers mot-a-mot*.js contre les textes (coran.js, torah.js, zabour.js, injil.js).
Usage : python3 verifier_mot_a_mot.py   (à lancer dans le dossier du site)
Affiche, par livre : versets couverts, versets au mauvais nombre de mots (à corriger), et ce qu'il reste à faire."""
import json,sys,re
def words(o): return [w for w in o.split() if not re.fullmatch(r'[\u2014\u2013\u2012-]+',w)]  # mêmes mots que l'application (tirets isolés exclus)
def load(f):
    s=open(f,encoding='utf-8').read(); i=s.index('={')+1
    return json.loads(s[i:].rstrip().rstrip(';'))
LIV={'coran':('coran.js','mot-a-mot.js'),'torah':('torah.js','mot-a-mot-torah.js'),
     'zabour':('zabour.js','mot-a-mot-zabour.js'),'injil':('injil.js','mot-a-mot-injil.js')}
for k,(tf,mf) in LIV.items():
    try: d=load(tf)
    except Exception as e: print(k,': texte introuvable',e); continue
    try: m=load(mf)
    except Exception: m={}
    tot=ok=bad=0; badl=[]; first_missing=None
    for b,bk in enumerate(d['books']):
        for c,ch in enumerate(bk['chapters']):
            for u in ch:
                tot+=1
                key=f"{b+1}:{u['n']}" if k=='coran' else f"{b+1}:{c+1}:{u['n']}"
                g=m.get(key)
                if g is None:
                    if first_missing is None: first_missing=key
                    continue
                if len(g)==len(words(u['o'])): ok+=1
                else: bad+=1; badl.append(f"{key} (attendu {len(words(u['o']))}, trouvé {len(g)})")
    extra=[x for x in m if x not in set()]
    print(f"{k:7s} {ok}/{tot} versets OK, {bad} à corriger, {tot-ok-bad} restants. Premier manquant : {first_missing}")
    for x in badl[:30]: print('   !',x)
